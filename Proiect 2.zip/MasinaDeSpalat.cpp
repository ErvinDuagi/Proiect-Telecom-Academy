#include "MasinaDeSpalat.h"

MasinaDeSpalat::MasinaDeSpalat(const string&nume,const int&id, const int&rotatiiPeMinut,const string&clasaEnergetica):
    Produs(id,nume),
    rotatiiPeMinut(rotatiiPeMinut),
    clasaEnergetica(clasaEnergetica)

{
    //ctor
}
int MasinaDeSpalat::getRotatii()
{
    return rotatiiPeMinut;
}
string MasinaDeSpalat::getClasaEnergetica()
{
    return clasaEnergetica;
}
