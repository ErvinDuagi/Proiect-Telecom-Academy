#ifndef MASINADESPALAT_H
#define MASINADESPALAT_H

#include "Produs.h"
#include <string>
#include <iostream>
using namespace std;


class MasinaDeSpalat : public Produs
{
    public:
        MasinaDeSpalat(const string&nume,const int&id,const int&rotatiiPeMinut, const string&clasaEnergetica);
         virtual ~MasinaDeSpalat() = default;
        int getRotatii();
        string getClasaEnergetica();


    protected:
        int rotatiiPeMinut;
        string clasaEnergetica;

    private:
};

#endif // MASINADESPALAT_H
