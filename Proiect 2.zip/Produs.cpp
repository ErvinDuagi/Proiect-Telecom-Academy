#include "Produs.h"

Produs::Produs(const int&id,const string&nume):id(id),nume(nume)
{

}
int Produs::getid()
{
    return id;
}

