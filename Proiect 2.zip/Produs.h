#ifndef PRODUS_H
#define PRODUS_H
#include <string>

using namespace std;


class Produs
{
    public:
        Produs(const int&id,const string&nume);
        virtual ~Produs() = default;
        int getid();
         int id;
        string nume;
        double pret;


    protected:


    private:

};

#endif // PRODUS_H
