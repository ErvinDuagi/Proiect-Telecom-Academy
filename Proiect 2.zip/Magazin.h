#ifndef MAGAZIN_H
#define MAGAZIN_H
#include "Produs.h"
#include "Magazin.h"
#include "MasinaDeSpalat.h"
#include "Exceptii.h"

class Magazin
{
    public:
        Magazin(const int &nr);
        virtual ~Magazin();
        void agaugaProdus(Produs* p);
        void eliminaProdus(int id);
        Produs*cautaProdus(int id);
         int numaraMasiniDeSpalat();
         void scrieProduse();

    void operator^(int elem);


    protected:

    private:
        Produs**raioane;
        int nrProduse;

};

#endif // MAGAZIN_H
