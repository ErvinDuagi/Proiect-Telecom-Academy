#include "Frigider.h"

Frigider::Frigider(const string&nume, const int&id,const double& pret,const int&volum) :
  Produs(id,nume),
  volum(volum)
{

}
int Frigider::getVolum()
{
    return volum;
}
bool Frigider::areCongelator()
{
    return volum>50;
}

