#ifndef FRIGIDER_H
#define FRIGIDER_H

#include "Produs.h"


class Frigider : public Produs
{
    public:
        Frigider(const string&nume,const int&id, const double&pret,const int&volum);
        bool areCongelator();
        int getVolum();



    protected:
        int volum;

    private:
};

#endif // FRIGIDER_H
