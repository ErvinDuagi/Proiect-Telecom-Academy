#include <iostream>
#include <string>
#include "Produs.h"
#include "Frigider.h"
#include "MasinaDeSpalat.h"
#include "Magazin.h"
#include "Exceptii.h"
using namespace std;

int main()
{


      Magazin m(100);
      char op;
       do
       {


      cout << "Introduceti optiunea" << endl;
        cout << " A - Adauga produs" << endl;
        cout << " E - Elimina produs" << endl;
        cout << " C - Cauta produs" << endl;
        cout << " N - Numara masinile de spalat " << endl;
        cout << " L - scrie produse" << endl;
        cout << " Q - La revedere "<<endl;

           int id;
           int id1,id2;

        cin >> op;
         switch(op) {
            case 'A':
                char op1;
                cout<<" Ce produs vreti sa adaugati ? M/F ";
                 cin>>op1;
                cout<<" introduceti id ";
                cin>>id;

                if(op1=='M')
                {
                    m.agaugaProdus(new MasinaDeSpalat("MasinaDeSpalat",id,300,"A+"));


                }
                if(op1=='F')
                {
                    m.agaugaProdus(new Frigider("Frigider",id,500,30));
                }

                 break;

           case 'E':
                cout<<" introduceti id ";
                cin>>id2;
               m.eliminaProdus(id); break;
           case 'C':
               cout<<" introduceti id ";
                cin>>id1;
            m.cautaProdus(id1); break;
           case 'L': m.scrieProduse(); break;
           case 'N': int nr; nr=m.numaraMasiniDeSpalat(); cout<< " numarul masinilor de spalat este : "<< nr; break;
         }


        }while(op!='Q');



    return 0;
}
