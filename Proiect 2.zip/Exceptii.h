
#ifndef EXCEPTII_H
#define EXCEPTII_H
class MagazinPlinException {};
class ProdusInexistentException {};

#endif // EXCEPTII_H
