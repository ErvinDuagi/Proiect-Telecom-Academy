#include "Magazin.h"
#include "Produs.h"
#include "MasinaDeSpalat.h"
#include "Frigider.h"
#include "Exceptii.h"
#include <iostream>
#include <string>

using namespace std;

Magazin::Magazin(const int&nr)
{
    nrProduse=nr;
    raioane=new Produs*[nrProduse];
    for(int i=0; i<nrProduse; i++)
    {
        raioane[i]=NULL;

    }

}
// Incercare de a supraincarca operatorul ^ intrucat nu am stiut sa fac altceva
void Magazin::operator^(int elem)
{
    cout<<"Magazinul este prea plin";
}
void Magazin::agaugaProdus(Produs*p)
{

    try
    {

        for(int i=0; i<=nrProduse; i++)
        {
            if(raioane[i]==NULL)
            {
                raioane[i]= p;

                return;
            }


        }
        throw MagazinPlinException();
    }
    catch(MagazinPlinException e)
    {
       operator^(1);
    }
}

int Magazin::numaraMasiniDeSpalat()
{
    int nr=0;
    for(int i=0; i<=nrProduse; i++)
    {
        if(raioane[i]!=NULL)
        {
            MasinaDeSpalat* m = dynamic_cast<MasinaDeSpalat*>(raioane[i]);
            if(m!=NULL)
                nr++;

        }
    }
    return nr;
}
void Magazin::scrieProduse()
{
    for(int i=0; i<=nrProduse; i++)
    {
        if(raioane[i]!=NULL)
        {
            cout<< raioane[i]->nume << " id : "<< raioane[i]->id;
            MasinaDeSpalat* m = dynamic_cast<MasinaDeSpalat*>(raioane[i]);
            if(m!=NULL)
                cout<<" Nr rotatii : "<<m->getRotatii()<<" Clasa energetica "<<m->getClasaEnergetica()<<endl;
            else
            {
                Frigider* f = dynamic_cast<Frigider*>(raioane[i]);
                cout<< " Volum : "<<f->getVolum();
                if(f->areCongelator())
                    cout<<" Frigiderul are congelator "<<endl;
                else cout <<"Fridigerul nu are congelator"<<endl;
            }
        }
    }
}
void Magazin::eliminaProdus(int id)
{   try{
    int ok=0;
    for(int i=0; i<=nrProduse; i++)
    {
        if(raioane[i]->id==id&&raioane[i]!=NULL)
              {

               delete raioane[i];
               ok=1;
                return;
              }

    }
      if(ok==0)
       {throw ProdusInexistentException();
       }

       } catch(ProdusInexistentException e)
        {
            cout<<" Produsul nu este in magazin"<<endl;
        }


}
Produs*Magazin::cautaProdus(int idprodus)
{
    try
    { int ok=0;
        for(int i=0; i<=nrProduse; i++)
        {
            if(raioane[i]->id==idprodus)
            {

                cout<<" Produsul este disponibil "<<endl;
                ok=1;
                 break;
            }
        }
        if(ok==0)
          throw ProdusInexistentException();
    }catch(ProdusInexistentException e){



        cout<<" Produsul nu este in magazin"<<endl;
    }

}

Magazin::~Magazin()
{
    for(int i=0; i<nrProduse; i++)
    {
        if(raioane[i]!=NULL)
            delete raioane[i];
    }
    delete [] raioane;
}

